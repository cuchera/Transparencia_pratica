import { Link } from "react-router";
import { Politician } from "../data/mockData";
import { ScoreIndicator } from "./ScoreIndicator";
import { MapPin, Briefcase } from "lucide-react";

interface PoliticianCardProps {
  politician: Politician;
}

export function PoliticianCard({ politician }: PoliticianCardProps) {
  return (
    <Link
      to={`/politician/${politician.id}`}
      className="bg-white rounded-lg border border-gray-200 p-6 hover:shadow-lg transition-shadow"
    >
      <div className="flex gap-4">
        <img
          src={politician.photo}
          alt={politician.name}
          className="w-20 h-20 rounded-full object-cover"
        />
        <div className="flex-1">
          <h3 className="font-semibold text-gray-900">{politician.name}</h3>
          <p className="text-sm text-blue-600">{politician.party}</p>
          <div className="flex gap-3 mt-2 text-sm text-gray-600">
            <div className="flex items-center gap-1">
              <MapPin className="w-4 h-4" />
              <span>{politician.state}</span>
            </div>
            <div className="flex items-center gap-1">
              <Briefcase className="w-4 h-4" />
              <span>{politician.position}</span>
            </div>
          </div>
        </div>
        <ScoreIndicator score={politician.score} size="sm" />
      </div>

      <div className="grid grid-cols-3 gap-4 mt-4 pt-4 border-t border-gray-100">
        <div>
          <p className="text-xs text-gray-500">Productivity</p>
          <p className="font-semibold text-gray-900">{politician.productivity}</p>
        </div>
        <div>
          <p className="text-xs text-gray-500">Attendance</p>
          <p className="font-semibold text-gray-900">{politician.attendance}%</p>
        </div>
        <div>
          <p className="text-xs text-gray-500">Cost/Unit</p>
          <p className="font-semibold text-gray-900">
            ${(politician.costPerProductivity / 1000).toFixed(1)}k
          </p>
        </div>
      </div>
    </Link>
  );
}
