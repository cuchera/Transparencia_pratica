import { useState, useMemo } from "react";
import { FilterBar } from "../components/FilterBar";
import { PoliticianCard } from "../components/PoliticianCard";
import {
  mockPoliticians,
  states,
  parties,
  positions,
  years,
} from "../data/mockData";

export function Home() {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedState, setSelectedState] = useState("All States");
  const [selectedParty, setSelectedParty] = useState("All Parties");
  const [selectedPosition, setSelectedPosition] = useState("All Positions");
  const [selectedYear, setSelectedYear] = useState("2026");

  const filteredPoliticians = useMemo(() => {
    return mockPoliticians.filter((politician) => {
      const matchesSearch = politician.name
        .toLowerCase()
        .includes(searchQuery.toLowerCase());
      const matchesState =
        selectedState === "All States" || politician.state === selectedState;
      const matchesParty =
        selectedParty === "All Parties" || politician.party === selectedParty;
      const matchesPosition =
        selectedPosition === "All Positions" ||
        politician.position === selectedPosition;

      return matchesSearch && matchesState && matchesParty && matchesPosition;
    });
  }, [searchQuery, selectedState, selectedParty, selectedPosition]);

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-semibold text-gray-900 mb-2">
            Political Representatives
          </h1>
          <p className="text-gray-600">
            Search and analyze public officials based on transparency and
            performance data
          </p>
        </div>

        <div className="mb-6">
          <FilterBar
            searchQuery={searchQuery}
            setSearchQuery={setSearchQuery}
            selectedState={selectedState}
            setSelectedState={setSelectedState}
            selectedParty={selectedParty}
            setSelectedParty={setSelectedParty}
            selectedPosition={selectedPosition}
            setSelectedPosition={setSelectedPosition}
            selectedYear={selectedYear}
            setSelectedYear={setSelectedYear}
            states={states}
            parties={parties}
            positions={positions}
            years={years}
          />
        </div>

        <div className="mb-4">
          <p className="text-sm text-gray-600">
            Showing {filteredPoliticians.length} result
            {filteredPoliticians.length !== 1 ? "s" : ""}
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {filteredPoliticians.map((politician) => (
            <PoliticianCard key={politician.id} politician={politician} />
          ))}
        </div>

        {filteredPoliticians.length === 0 && (
          <div className="text-center py-12">
            <p className="text-gray-500">
              No politicians found matching your criteria
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
